﻿namespace Exercice_9_1.Dll
{
    /// <summary>
    /// Interface de la console
    /// </summary>
    public interface IConsole
    {
        void WriteLine(string input);

        string ReadLine();
    }
}