﻿namespace Exercice_9_1.Dll
{
    /// <summary>
    /// Interface de Random
    /// </summary>
    public interface IRandom
    {
        int Next(int min, int max);
    }
}