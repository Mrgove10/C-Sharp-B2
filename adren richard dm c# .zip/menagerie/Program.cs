namespace menagerie
{
    internal class Program
    {
        /// <summary>
        /// boucle principale du programe
        /// </summary>
        /// <param name="args"></param>
        private static void Main(string[] args)
        {
            menagerie MyMenagerie = new menagerie();
            MyMenagerie.CreationMenagerie();
        }
    }
}