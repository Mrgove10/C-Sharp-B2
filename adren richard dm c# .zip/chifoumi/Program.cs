namespace chifoumi
{
    internal class Program
    {
        //boucle de demarage du program
        private static void Main(string[] args)
        {
            Jeu Game = new Jeu();
            Game.menu();
        }
    }
}